//Hoa Ho
//892119547
package project_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter; 
import java.util.Scanner; 

/*Each class declaration should begin with comments in the following format:
/**
main method which run the code. Add or remove from the order list and print in the file
*
CSC 1351 Programming Project No 1
7
Section 2
*
@author Hoa Ho (hho21)
@since 3/17/2024
*
*/
public class Prog01_aOrderedList 
{
	/**
    the main method which add or delete things from file
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public static void main(String[] args) 
	{
		aOrderedList carList = new aOrderedList(); //an orderlist
		try 
		{
			Scanner in = GetInputFile("Enter input filename: ");
			PrintWriter out = GetOutputFile ("Enter output filename: ");
			
			while (in.hasNextLine())
			{
				String carData = in.nextLine(); //store the next line as car data
				String [] parts = carData.split(","); //separate the make,price, and year into parts
				String input = parts [0]; 
				if (input.equals("A"))
				{
					String make = parts[1];
					int year = Integer.parseInt(parts[2]);
					int price = Integer.parseInt(parts[3]);
					Car newCar = new Car (make, year, price);
					carList.add(newCar);
				}
				else if (input.equals("D"))
				{
					if (parts.length == 3)
					{	
						String make = parts[1];
						int year = Integer.parseInt(parts[2]);
						carList.remove(make, year);
					}
				
					else if (parts.length == 2)
					{
					carList.remove(Integer.parseInt(parts [1]));
					}
				 }
				}
			in.close();
			outputList(out,carList);
			out.close();
		}
		catch (FileNotFoundException e)
		{
			System.out.println("File not found.");
		}
	}
	 

	/**
	get the user input and check if file exist. 
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException
	{
		Scanner in = new Scanner(System.in);
		while (true) 
		{
				System.out.println(UserPrompt);
				String filename = in.nextLine(); //store the next user input as a filename
				File file = new File(filename); //store file
				if (!file.exists()) 
				{
					System.out.println("File specified <" + filename + "> does not exist. Would you like to continue? <Y/N>");
					String answer = in.nextLine();
					if (answer.equals("N")) 
					{
						in.close();
						throw new FileNotFoundException();
					}
					else if (answer.equals("Y")) 
					{
						continue; 
					}
				}
				else 
				{	
				return new Scanner(file);
				}
		}
	}
	/**
	store the user output file and check if it exist
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public static PrintWriter GetOutputFile (String UserPrompt) throws FileNotFoundException //Userprompt is the user input
	 {
		try (Scanner in = new Scanner (System.in)) 
		{
			String filename;
				while(true)
				{
					System.out.print(UserPrompt);
					filename = in.nextLine();
					File folder = new File(filename);
					if (folder.exists())
					{
						return new PrintWriter(folder);
					}
					else 
					{
						System.out.println("Folder is write-protected. Would you like to continue? <Y/N>");
						String answer = in.nextLine();
						if (answer.equals("N")||answer.equals("n"))
						{
							throw new FileNotFoundException();
						}
						
					}
								
				}
		}
			
	 }
	/**
	print the list of car with the value make,year,and price in the output file
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	 public static void outputList(PrintWriter out, aOrderedList carList)
	 {
		 out.println("Number of cars: " + carList.size());
		 carList.reset();
		 while (carList.hasNext()) 
		 {
		 
		Car Car = (Car) carList.next();	 
		 out.println("\nMake: \t" + Car.getMake());
		 out.println("Year: \t" + Car.getYear());
		 out.println("Price: $" + Car.getPrice());
		 }	 
	 }
	 
}	


