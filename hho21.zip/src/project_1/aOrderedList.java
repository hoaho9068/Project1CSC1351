//Hoa Ho
//892119547
package project_1;
import java.util.NoSuchElementException;
import java.util.Arrays;

/*Each class declaration should begin with comments in the following format:
/**
create a list that add/delete and organize the list
*
CSC 1351 Programming Project No 1
7
Section 2
*
@author Hoa Ho (hho21)
@since 3/17/2024
*
*/
public class aOrderedList 
{
	final int SIZEINCREMENTS = 20; 

	private Comparable [] oList; //a generic list that is comparable used to organize the content 
	private int listSize; //store the list size
	private int numObjects; //store the numbers of car in the list
	private int current; //store the current car that is on the list
	private Comparable Element; //store a comparable eleement

	/**
	give value to the numObjects, listSize, OList, and current variables
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public aOrderedList()
	{
		numObjects = 0;
		listSize = SIZEINCREMENTS; 
		oList = new Car [SIZEINCREMENTS];
		current = 0; 
	}

	/**
	add more car objects and increase index size of the orderlist
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public void add (Car newObject)
	{
		if (numObjects == listSize)
		{
			listSize += SIZEINCREMENTS;
			oList = Arrays.copyOf(oList, listSize);
		}
		int insertIndex = 0;
		
		while (insertIndex < numObjects && oList [insertIndex].compareTo(newObject )<0)
		{
			insertIndex++ ;  
		}
		System.arraycopy(oList,insertIndex, oList, insertIndex +1, numObjects - insertIndex);
		oList[insertIndex] = newObject; 
		numObjects++;
	}
	public Comparable next() {
	 	if (!hasNext()) {
	 		throw new NoSuchElementException(); 
	 	}
	 	else {
	 		this.Element = this.oList[this.current++];
	 		return this.Element;
	 	}
 	}
	/**
	return an index of a Car object
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public Car get(int index)
	{
	 return (Car) oList[index];
	}
	/**
	return the next car if it has another in the list. if not it return nothing
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	
	/**
	check if there another car after the current car in the list.  
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public boolean hasNext()
	{
		return current < numObjects; 
	}
	/**
	reset the current car to 0
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public void reset()
	{
		current = 0;
	}
	/**
	*return the number of current cars in the order list
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public  int size()
	{
		return numObjects;
	}
	/**
	check if the current number of cars in the list is equal to 0
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public boolean isEmpty()
	{
		return numObjects ==0;
	}
	/**
	remove a car object base on the make and year
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public void remove(String make, int year) 
	{
	    for (int i = 0; i <= numObjects - 1; i++) 
	    {
	        Car car = (Car) oList[i]; 
	        if (car.getMake().equals(make) && car.getYear() == year)  //find car that match description
	        {
	            System.arraycopy(oList, i + 1, oList, i, numObjects - i - 1);
	            numObjects--;
	          
	        }
	    }
	   
	}
	/**
	remove a car object base on the index number 
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public void remove(int index)  
	{
		if (index < 0 || index >= numObjects) //check if the index is out of bound 
	    {
	      throw new IndexOutOfBoundsException("Index out of bounds: " + index); 
	    }
	    
		else 
		{
			for (int i = index; i < numObjects -1 ; i++) 
			{
	        oList[i] = oList[i + 1];
			}
			System.arraycopy(oList, index + 1, oList, index, numObjects - index -1);
			numObjects--;
		}
	   
	}
	/**
	format the list with comma and bracket
	*
	CSC 1351 Programming Project No  1
	Section 2
	*
	@author Hoa Ho (hho21)
	@since (3/17/2024)
	*
	*/
	public String toString()
	{
		StringBuilder format = new StringBuilder ("[");
		for (int i =0; i< numObjects; i++)
		{
			format.append(oList[i].toString());
			if (i < numObjects - 1)
			{
				format.append(", ");
			}
		}
		format.append("]");
		return format.toString();
	}
}