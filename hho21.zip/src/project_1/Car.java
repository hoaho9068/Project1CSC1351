//Hoa Ho
//892119547

/*Each class declaration should begin with comments in the following format:
make a constructor to create represent car objects. 
*
CSC 1351 Programming Project No 1
7
Section 2
*
@author Hoa Ho (hho21)
@since 3/17/2024
*
*/
package project_1;

class Car implements Comparable<Car> 
 {
  
   private String make; // store represent the car brand
   private int year;    // store the year which the car was release
   private int price;   //store the price of the car

   /**
   a constructor to give instant variable values
   *
   CSC 1351 Programming Project No  1
   Section 2
   *
   @author Hoa Ho (hho21)
   @since (3/17/2024)
   *
   */
   public  Car (String Make, int Year, int Price)
	 {
		this.make = Make;
		this.year = Year;
		this.price = Price;
	 } 

   /**
   return the value of make
   *
   CSC 1351 Programming Project No  1
   Section 2
   *
   @author Hoa Ho (hho21)
   @since (3/17/2024)
   *
   */
   public String getMake()
     {
      return make; 	
     }
   /**
   return the value of year
   *
   CSC 1351 Programming Project No  1
   Section 2
   *
   @author Hoa Ho (hho21)
   @since (3/17/2024)
   *
   */
    public int getYear()
     {
	  return year;   
     }
    /**
    return the value of price
    *
    CSC 1351 Programming Project No  1
    Section 2
    *
    @author Hoa Ho (hho21)
    @since (3/17/2024)
    *
    */
   public int getPrice()
    {
	 return price;    
    }
   
   /**
 	compare car objects by make then year. 
   *
   CSC 1351 Programming Project No  1
   Section 2
   *
   @author Hoa Ho (hho21)
   @since (3/17/2024)
   *
   */
   public int compareTo(Car other)
    {
	 if (make.compareTo(other.make)!= 0)
		return make.compareTo(other.make);
	 else 
		return Integer.compare(year, other.year);
    }
   /**
 make a string that give show values of price, make, and year
   *
   CSC 1351 Programming Project No  1
   Section 2
   *
   @author Hoa Ho (hho21)
   @since (3/17/2024)
   *
   */
   public String toString() 
    {
	 return ("Make: " + make + ", Year: " + year + ", Price: $" + price + ";");    
    }
 }
